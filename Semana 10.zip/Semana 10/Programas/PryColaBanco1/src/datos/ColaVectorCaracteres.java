
package datos;

public class ColaVectorCaracteres
{
    String elemento[];
    int primero, ultimo, n;
    
    public ColaVectorCaracteres(int tam)
    {
        elemento = new String[tam];
        n = tam;

        primero = -1;
        ultimo = -1;
    }

    public void adicionar(String dato)
    {
        if (primero == -1)
        {
            primero = 0;
            ultimo = 0;
        }
        else
            if (ultimo == n - 1)
                ultimo = 0;
            else
                ultimo = ultimo + 1;

        elemento[ultimo] = dato;
    }

    public void atender()
    {
        if (primero == ultimo)
        {
            primero = -1;
            ultimo = -1;
        }
        else
            if (primero == n - 1)
                primero = 0;
            else
                primero = primero + 1;
    }

    public int getPrimero()
    {
        return primero;
    }

    public int getUltimo()
    {
        return ultimo;
    }

    public String getElemento(int pos)
    {
        return elemento[pos];
    }
}

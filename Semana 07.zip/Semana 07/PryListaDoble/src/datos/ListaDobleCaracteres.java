
package datos;

public class ListaDobleCaracteres
{
    public Nodo inicio, fin;
    
    public ListaDobleCaracteres()
    {
        inicio = null;
        fin = null;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo;
        
        nuevo = new Nodo();
        nuevo.info = dato;
        nuevo.sgte = null;
        nuevo.ante = fin;

        if(inicio == null)
            inicio = nuevo;
        else
            fin.sgte = nuevo;
        
        fin = nuevo;
    }
}


package datos;

public class Nodo 
{
    public String info;
    public Nodo sgte;
    public Nodo ante;
}

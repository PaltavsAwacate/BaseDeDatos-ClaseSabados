
package datos;

public class ListaCircularCaracteres
{
    public Nodo inicio;
    
    public ListaCircularCaracteres()
    {
        inicio = null;
    }
    
    public Nodo retornarUltimo()
    {
        Nodo p = inicio;
        
        while(p.sgte != inicio)
            p = p.sgte;
        
        return p;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo, ultimo;
        
        nuevo = new Nodo();
        nuevo.info = dato;
        
        if(inicio == null)
        {
            nuevo.sgte = nuevo;
            inicio = nuevo;
        }
        else
        {
            nuevo.sgte = inicio;
            ultimo = retornarUltimo();
            ultimo.sgte = nuevo;
        }
    }
}

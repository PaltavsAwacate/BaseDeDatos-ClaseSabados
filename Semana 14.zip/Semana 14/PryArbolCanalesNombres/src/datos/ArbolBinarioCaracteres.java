
package datos;

public class ArbolBinarioCaracteres
{
    public Nodo raiz;
    private int contaEfi;

    public ArbolBinarioCaracteres()
    {
        raiz = null;
    }
    
    public int getContaEfi()
    {
        return contaEfi;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo, actual, padre = null;

        nuevo = new Nodo();
            
        nuevo.info = dato;
        nuevo.izq  = null;
        nuevo.der  = null;

        if (raiz == null)
            raiz = nuevo;
        else
        {
            actual = raiz;
            while (actual != null)
            {
                padre = actual;
                if (dato.compareTo(actual.info) < 0)
                    actual = actual.izq;
                else
                    actual = actual.der;
            }
            
            if (dato.compareTo(padre.info) < 0)
                padre.izq = nuevo;
            else
                padre.der = nuevo;
        }
    }
    
    public Nodo buscar(String dato)
    {
        Nodo p = raiz;
        contaEfi = 0;
        
        while(p != null)
        {
            contaEfi = contaEfi + 1;
            
            if(dato.equals(p.info))
                return p;
            else
                if(dato.compareTo(p.info) < 0)
                    p = p.izq;
                else
                    p = p.der;
        }
        return null;
    }
    
}

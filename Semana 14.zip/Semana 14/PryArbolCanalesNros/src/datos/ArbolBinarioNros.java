
package datos;

public class ArbolBinarioNros
{
    public Nodo raiz;
    private int contaEfi;

    public ArbolBinarioNros()
    {
        raiz = null;
    }
    
    public int getContaEfi()
    {
        return contaEfi;
    }
    
    public void adicionar(double dato)
    {
        Nodo nuevo, actual, padre = null;

        nuevo = new Nodo();
            
        nuevo.info = dato;
        nuevo.izq  = null;
        nuevo.der  = null;

        if (raiz == null)
            raiz = nuevo;
        else
        {
            actual = raiz;
            while (actual != null)
            {
                padre = actual;
                if (dato < actual.info)
                    actual = actual.izq;
                else
                    actual = actual.der;
            }
            
            if (dato < padre.info)
                padre.izq = nuevo;
            else
                padre.der = nuevo;
        }
    }
    
    public Nodo buscar(double dato)
    {
        Nodo p = raiz;
        contaEfi = 0;
        
        while(p != null)
        {
            contaEfi = contaEfi + 1;
            
            if(dato == p.info)
                return p;
            else
                if(dato < p.info)
                    p = p.izq;
                else
                    p = p.der;
        }
        return null;
    }
}
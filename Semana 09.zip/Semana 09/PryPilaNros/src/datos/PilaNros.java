
package datos;

public class PilaNros
{
    double elemento[];
    int cima;

    public PilaNros(int tam)
    {
        elemento = new double[tam];
        cima = -1;
    }

    public void poner(double dato)
    {
        cima = cima + 1;
        elemento[cima] = dato;
    }

    public void sacar()
    {
        cima = cima - 1;
    }

    public int getCima()
    {
        return cima;
    }

    public double getElemento(int pos)
    {
        return elemento[pos];
    }
}

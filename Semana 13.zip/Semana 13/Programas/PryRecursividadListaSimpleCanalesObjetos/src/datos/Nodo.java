
package datos;

public class Nodo
{
    public CanalTV info;
    public Nodo sgte;
}

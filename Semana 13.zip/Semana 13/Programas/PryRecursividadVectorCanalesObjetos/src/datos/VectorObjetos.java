package datos;

public class VectorObjetos
{
    private CanalTV elementos[];
    private int conta;
    
    public VectorObjetos(int tamaño)
    {
        conta = 0;
        elementos = new CanalTV[tamaño];
    }

    public void adicionar(CanalTV dato)
    {
        elementos[conta] = dato;
        conta = conta + 1;
    }

    public int getConta()
    {
        return conta;
    }

    public CanalTV getElemento(int pos)
    {
       return elementos[pos];
    }
        
    public int buscarPorNro(int dato)
    {
        int i;

        for (i=0; i<conta; i=i+1)
            if (elementos[i].nro == dato)
                return i;
            
        return -1;
    }
    
    public void modificar(CanalTV dato, int pos)
    {
        elementos[pos] = dato;
    }

    public void ordenarPorNro()    // Ordenamiento ascendente
    {
        int i, j;
        CanalTV tempo;
    
        for(i=0; i<conta-1; i=i+1)
            for(j=i+1; j<conta; j=j+1)
                if (elementos[i].nro > elementos[j].nro)
                {
                    tempo = elementos[i];
                    elementos[i] = elementos[j];
                    elementos[j] = tempo;
                }
    }

    public void eliminarPorPosicion(int p)
    {
        int i;

        for (i = p; i < (conta - 1); i++)
            elementos[i] = elementos[i + 1];

        conta = conta - 1;
    }
    
    public int buscarPorNroRecursivo(int i, int dato)   // método recursivo
    {
        if(i < 0)
            return -1;
        else
            if(elementos[i].nro == dato)
                return i;
            else
                return buscarPorNroRecursivo(i-1, dato);
    }
}

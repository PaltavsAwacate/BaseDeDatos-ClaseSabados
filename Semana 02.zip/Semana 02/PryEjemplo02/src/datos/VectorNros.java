
package datos;

public class VectorNros
{
    private double elemento[];
    private int conta;
    
    public VectorNros(int tamaño)
    {
        elemento = new double[tamaño];
        conta = 0;
    }
    
    public void adicionar(double dato)
    {
        elemento[conta] = dato;
        conta = conta + 1;
    }
    
    public int getConta()
    {
        return conta;
    }
    
    public double getElemento(int pos)
    {
        return elemento[pos];
    }
}


package datos;

public class VectorNros
{
    private double elemento[];
    private int conta;
    
    public VectorNros(int tamaño)
    {
        conta = 0;
        elemento = new double[tamaño];
    }
    
    public void adicionar(double dato)
    {
        elemento[conta] = dato;
        conta = conta + 1;
    }
    
    public int getConta()
    {
        return conta;
    }
    
    public double getElemento(int pos)
    {
        return elemento[pos];
    }
}

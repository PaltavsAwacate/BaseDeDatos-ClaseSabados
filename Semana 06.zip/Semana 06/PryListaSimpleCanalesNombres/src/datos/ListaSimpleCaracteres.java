
package datos;

public class ListaSimpleCaracteres
{
    public Nodo inicio;
    private int contaEfi;
    
    public ListaSimpleCaracteres()
    {
        inicio = null;
    }
    
    public Nodo retornarAnterior(Nodo q)
    {
        Nodo p = inicio;
        
        while(p.sgte != q)
            p = p.sgte;
        
        return p;
    }
    
    public Nodo retornarUltimo()
    {
        Nodo p = inicio;
        
        while(p.sgte != null)
            p = p.sgte;
        
        return p;
    }
    
    public int getContaEfi()
    {
        return contaEfi;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo, ultimo;
        
        nuevo = new Nodo();
        nuevo.info = dato;
        nuevo.sgte = null;
        
        if(inicio == null)
            inicio = nuevo;
        else
        {
            ultimo = retornarUltimo();
            ultimo.sgte = nuevo;
        }
    }
    
    public Nodo buscar(String dato)
    {
        // implementar
        return null;
    }
    
    public void ordenar()
    {
        // implementar
    }
    
    public void insertarAntes(String dato, Nodo actual)
    {
        // implementar
    }
    
    public void insertarDespues(String dato, Nodo actual)
    {
        // implementar
    }
}

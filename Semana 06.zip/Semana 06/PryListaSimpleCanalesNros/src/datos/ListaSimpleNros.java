
package datos;

public class ListaSimpleNros
{
    public Nodo inicio;
    private int contaEfi;

    public ListaSimpleNros()
    {
        inicio = null;
    }
    
    public int getContaEfi()
    {
        return contaEfi;
    }
    
    public Nodo retornarUltimo()    // devuelve la dirección de memoria
    {                               // del último elemento de la Lista
        Nodo p = inicio;

        while (p.sgte != null)
            p = p.sgte;

        return p;
    }

    public Nodo retornarAnterior(Nodo q)    // devuelve la dirección de memoria
    {                                       // del elemento anterior a q
        Nodo p = inicio;

        while (p.sgte != q)
            p = p.sgte;

        return p;
    }

    public void adicionar(double dato)  // inserción al final de la Lista
    {
        Nodo nuevo, ultimo;
        nuevo = new Nodo();

        nuevo.info = dato;
        nuevo.sgte = null;

        if (inicio == null)
            inicio = nuevo;
        else
        {
            ultimo = retornarUltimo();
            ultimo.sgte = nuevo;
        }
    }

    public Nodo buscar(double dato)
    {
        contaEfi = 0;
        Nodo p = inicio;
    
        while (p != null)
        {
            contaEfi = contaEfi + 1;
            
            if (p.info == dato)
                return p;

            p = p.sgte;
        }
        return null;
    }
    
    public void eliminar(Nodo actual)
    {
        Nodo anterior;

        if (actual == inicio)
            inicio = actual.sgte;
        else
        {
            anterior = retornarAnterior(actual);
            anterior.sgte = actual.sgte;
        }
    }
    
    public void ordenar()
    {
        Nodo p, q;
        double tempo;
        
        contaEfi = 0;
        p = inicio;
        
        while(p.sgte != null)
        {
            q = p.sgte;
            while(q != null)
            {
                contaEfi = contaEfi + 1;
                
                if(p.info > q.info)
                {
                    tempo = p.info;
                    p.info = q.info;
                    q.info = tempo;
                }
                q = q.sgte;
            }
            p = p.sgte;
        }
    }
    
    public int contar()
    {
        int conta = 0;
        Nodo p = inicio;
        
        while(p != null)
        {
            conta = conta + 1;
            p = p.sgte;
        }
        
        return conta;
    }
    
    public void insertarAlInicio(double dato)
    {
        
    }
}


package datos;

public class ArbolBinarioObjetos
{
    public Nodo raiz;
    
    public ArbolBinarioObjetos()
    {
        raiz = null;
    }
    
    public void adicionar(CanalTV dato)
    {
        Nodo nuevo, actual, padre = null;

        nuevo = new Nodo();
            
        nuevo.info = dato;
        nuevo.izq  = null;
        nuevo.der  = null;

        if (raiz == null)
            raiz = nuevo;
        else
        {
            actual = raiz;
            while (actual != null)
            {
                padre = actual;
                if (dato.nro < actual.info.nro)
                    actual = actual.izq;
                else
                    actual = actual.der;
            }
            
            if (dato.nro < padre.info.nro)
                padre.izq = nuevo;
            else
                padre.der = nuevo;
        }
    }
}


package datos;

public class ArbolBinarioCaracteres
{
    public Nodo raiz;

    public ArbolBinarioCaracteres()
    {
        raiz = null;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo, actual, padre = null;

        nuevo = new Nodo();
            
        nuevo.info = dato;
        nuevo.izq  = null;
        nuevo.der  = null;

        if (raiz == null)
            raiz = nuevo;
        else
        {
            actual = raiz;
            while (actual != null)
            {
                padre = actual;
                if (dato.compareTo(actual.info) < 0)
                    actual = actual.izq;
                else
                    actual = actual.der;
            }
            
            if (dato.compareTo(padre.info) < 0)
                padre.izq = nuevo;
            else
                padre.der = nuevo;
        }
    }
    
    public Nodo buscar(String dato)
    {
        // implementar
        return null;
    }
    
    public int contarNodos(Nodo p)
    {
        // implementar
        return 0;
    }
}

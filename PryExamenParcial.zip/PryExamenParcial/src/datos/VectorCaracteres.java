
package datos;

public class VectorCaracteres
{
    private String elemento[];
    private int conta;
    
    public VectorCaracteres(int tamaño)
    {
        conta = 0;
        elemento = new String[tamaño];
    }
    
    public void adicionar(String dato)
    {
        elemento[conta] = dato;
        conta = conta + 1;
    }
    
    public int getConta()
    {
        return conta;
    }
    
    public String getElemento(int pos)
    {
        return elemento[pos];
    }
    
    public void ordenar()   // algoritmo burbuja
    {
        String tempo;
        int i, j;
        
        for(i=0; i<conta-1; i=i+1)
            for(j=i+1; j<conta; j=j+1)
                if(elemento[i].compareTo(elemento[j]) > 0)
                {
                    tempo = elemento[i];
                    elemento[i] = elemento[j];
                    elemento[j] = tempo;
                }
    }
}
